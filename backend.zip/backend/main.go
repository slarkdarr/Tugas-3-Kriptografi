package main

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/slarkdarr/Tugas-2-Kriptografi/internal/impl"
)

// messageBody represents data about the body of a message.
type Message struct {
  Key string `json:"key"`
  Body string `json:"body"`
}

func EncryptMessage(key string, ciphertext string) string {
  c := impl.NewCipher(key)
  enc := c.Encrypt(ciphertext)
  return enc
}

func DecryptMessage(key string, plaintext string) string {
  c := impl.NewCipher(key)
  dec := c.Decrypt(plaintext)
  return dec
}

// encrypt function encrypts a message from JSON received in the request body.
func encrypt(c *gin.Context) {
  if c.Request.URL.Path != "/encrypt" {
    c.IndentedJSON(http.StatusNotFound, "404 not found.")
    return
  }

  if c.Request.Method != "POST" {
    c.IndentedJSON(http.StatusNotFound, "Method is not supported.")
    return
  }

  var message Message

  // Call BindJSON to bind the received JSON to
  // body.
  if err := c.BindJSON(&message); err != nil {
    c.IndentedJSON(http.StatusBadRequest, err.Error())
    return
  }

  fmt.Println(message)
  res := EncryptMessage(message.Key, message.Body)
  fmt.Println(res)

  c.IndentedJSON(http.StatusAccepted, res)
}

// decrypt function encrypts a message from JSON received in the request body.
func decrypt(c *gin.Context) {
  if c.Request.URL.Path != "/decrypt" {
    c.IndentedJSON(http.StatusNotFound, "404 not found.")
    return
  }

  if c.Request.Method != "POST" {
    c.IndentedJSON(http.StatusNotFound, "Method is not supported.")
    return
  }

  var message Message

  // Call BindJSON to bind the received JSON to
  // body.
  if err := c.BindJSON(&message); err != nil {
    c.IndentedJSON(http.StatusBadRequest, err.Error())
    return
  }

  fmt.Println(message)
  res := DecryptMessage(message.Key, message.Body)
  fmt.Println(res)

  c.IndentedJSON(http.StatusAccepted, res)
}

// func getArrayOfHex(text string) []string {
// 	data, _ := base64.StdEncoding.DecodeString(text)
// 	hexArr := make([]string, len(data))
// 	for i, b := range data {
// 		hexArr[i] = fmt.Sprintf("%02X", b)
// 	}
// 	return hexArr
// }

func main() {
	// c := impl.NewCipher("t6w9z$C&F)H@McQf")
	// testcase := []string{
	// 	"kriptografi",
	// 	"kr1ptografi",
	// 	"christo daffa abc",
	// 	"christo daffa abd",
	// 	"christo viel daf",
	// 	"christo viel d4f",
	// 	"christo vieldaff",
	// 	"khristo vieldaff",
	// 	"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
	// }
	// for i, each := range testcase {
	// 	fmt.Println("Testcase", i, "->", each)
	// 	enc := c.Encrypt(each)
	// 	fmt.Println("E\t: ", enc)
	// 	// fmt.Println("E (HEX)\t: ", getArrayOfHex(enc))
	// 	dec := c.Decrypt(enc)
	// 	fmt.Println("D\t: ", dec)
	// }

  router := gin.Default()
	router.POST("/encrypt", encrypt)
  router.POST("/decrypt", decrypt)

	fmt.Println("Starting server at port 8080...")
	router.Run("localhost:8080")

  // key := "t6w9z$C&F)H@McQf"
  // c := impl.NewCipher(key)
  // enc_result := c.Encrypt("mabar kuy")
  // fmt.Println(enc_result)
  // fmt.Println(c.Decrypt(enc_result))
  // enc_result := EncryptMessage(key, "mabar kuy")
  // fmt.Println(enc_result)
  // fmt.Println(DecryptMessage(key, enc_result))
}
