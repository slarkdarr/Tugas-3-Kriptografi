# Tugas 2 Kriptografi
Merancang dan mengimplementasikan Cipher Blok "Baru"